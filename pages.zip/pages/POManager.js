import { LoginPage } from "./LoginPage"
import { DashboardPage } from "./DashboardPage"
import { CartPage } from "./CartPage"
import { CheckOutPage } from "./CheckoutPage"
import { OrdersListPage } from "./OrdersListPage"
import { ThankYouPage } from "./ThankYouPage"
import { OrderDetailsPage } from "./OrderDetailsPage"

class POManager {
    constructor(page) {
        this.page = page
        this.loginPage = new LoginPage(page)
        this.dashboardPage = new DashboardPage(page)
        this.cartPage = new CartPage(page)
        this.checkoutPage = new CheckOutPage(page)
        this.ordersPage = new OrdersListPage(page)
        this.thankYouPage = new ThankYouPage(page)
    }

    getLoginPage() {
        return this.loginPage
    }

    getDashboardPage() {
        return this.dashboardPage
    }

    getCartPage() {
        return this.cartPage
    }

    getCheckoutPage() {
        return this.checkoutPage
    }

    getOrdersListPage() {
        return this.ordersListPage
    }
    getThankYouPage() {
        return this.thankYouPage
    }
    getOrdersDetailPage() {
        return this.ordersDetailPage
    }
}

module.exports = { POManager }