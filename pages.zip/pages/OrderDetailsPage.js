class OrderDetailsPage {
    constructor(page) {
        this.page = page
        this.orderId = page.locator(".-main")
    }
    async getOrderId() {
        return await this.orderId.textContent()
    }
}
module.exports = { OrderDetailsPage }